public int fib(int n) {
    int[] results = new int[n+1];
    results[__] = __;
    results[__] = __;
    for (int i = __; i <= __; i++) {

        ___________________________________________;
    }
    return ______________________;
}